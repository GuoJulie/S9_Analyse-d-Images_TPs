Base d'apprentissage pour le Tagging d'images: 
https://celene.univ-tours.fr/mod/resource/view.php?id=267662