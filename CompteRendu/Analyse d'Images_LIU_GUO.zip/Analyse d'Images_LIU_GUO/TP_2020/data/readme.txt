Images et scripts pour les TP 2020 (parties 1 à 3):
https://celene.univ-tours.fr/mod/resource/view.php?id=482077